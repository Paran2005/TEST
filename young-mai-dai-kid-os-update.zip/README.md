# YANG-MAI–DAI-KID OS 2.0 · GitHub update package

อัปโหลดไฟล์ `index.html` จากโฟลเดอร์นี้ไปแทนที่ไฟล์ `index.html` ที่ root ของ repository `Paran2005/TEST` แล้ว commit ไปยัง branch `main` เพื่ออัปเดต GitHub Pages

ตัวอย่างบุคลากร ภารกิจ ภูมิภาค และผลจำลองเป็นข้อมูลสังเคราะห์เพื่อการนำเสนอ ข้อมูลที่ผู้ใช้เพิ่มจะบันทึกใน Local Storage ของเบราว์เซอร์นั้น
