# GitHub Pages upload

Use `index.html` in this folder to update the root page of the GitHub repository `Paran2005/TEST`.

On GitHub, open the repository, choose **Add file → Upload files**, select this `index.html`, and commit it to the `main` branch. This replaces the current root `index.html` and lets GitHub Pages rebuild the site.

This standalone HTML includes the 50 Thai public-sector scenarios, category-first scenario browsing, custom scenario creation, and 0–100% scenario assumptions. Example organizations, personnel, and simulation results are synthetic.
